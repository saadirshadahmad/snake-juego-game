# SNAKEJUEGO — Complete Website PRD & Development Prompt

> **Purpose:** Use this document as the master build prompt for an AI coding agent or developer. Build a complete, production-ready, Spanish-language Snake gaming website named **SNAKEJUEGO**, using the supplied `snakegame.net` screenshot only as a layout/reference guide. The finished site must have its own brand identity, original content, clean code, strong technical SEO, responsive layouts, and a reliable embedded game experience.

---

## 1. Role and project objective

Act as a senior product designer, UX/UI designer, Next.js engineer, technical SEO specialist, accessibility engineer, and performance engineer. Plan and build the complete SNAKEJUEGO website—not just a static mockup.

SNAKEJUEGO is a lightweight browser gaming website where visitors can play the publicly embeddable Google Snake game directly on the website. The game is hosted externally and embedded through its official/publicly supported iframe URL supplied by the site owner. Do not recreate the game engine unless explicitly requested. Do not scrape, proxy, copy, or bypass restrictions on the external game.

The website itself must:

- Be primarily in **Spanish**. All visible interface labels, navigation, page copy, buttons, form validation, messages, blog content, and legal-page content must be natural Spanish.
- Place the playable game prominently near the top of the homepage so visitors can reach it immediately.
- Keep the gameplay area visually centered within the main content column.
- Reserve a clean, empty space to the right of the gameplay area on wide screens for a possible future banner-ad placement. **Do not insert advertisements, ad network code, sample ads, sponsored cards, or fake ad content.**
- Use the supplied screenshot as a structural reference: header, game near the top, a content area below the game, and footer. Do not copy its advertisements, third-party promotional blocks, exact text, or branding.
- Provide a blog, informational pages, contact page, and complete legal-page structure.
- Be technically optimized for crawling, rendering, indexing, loading speed, responsive behavior, accessibility, and maintainability.

### Brand and ownership safeguards

- The website brand is **SNAKEJUEGO**. Do not use `SNAKEGAME.NET` or any other reference-site branding.
- Do not use Google's logo or make the site look like an official Google property.
- Use the phrase “Google Snake” descriptively where accurate, but clearly explain that SNAKEJUEGO is an independent website and is not affiliated with or endorsed by Google.
- Do not claim ownership of the embedded game. The game remains hosted by its source provider.
- Do not invent legal company details, physical addresses, business registration numbers, contact details, or claims about data handling. Use clearly marked configuration placeholders where real owner information is required.

---

## 2. Required technology stack

Use this stack unless a genuine technical blocker requires an alternative. Explain any proposed deviation before implementing it.

| Layer | Required choice | Implementation notes |
|---|---|---|
| Framework | Next.js App Router | Use the current stable Next.js release available in the project environment. |
| UI | React | Keep the component tree small and purposeful. |
| Language | TypeScript | Enable strict type checking. |
| Styling | Custom CSS / CSS Modules | Prefer lightweight custom CSS and CSS variables. Do not add Tailwind solely out of habit. |
| Main rendering | Static generation / Server Components | Pre-render the homepage, informational pages, legal pages, blog index, and blog articles wherever possible. |
| Game | External iframe embed | Use the exact public embed URL provided by the site owner. Do not build a second game engine. |
| Blog content | Local MDX or typed local content files | Avoid a database or CMS for the initial version unless explicitly requested. |
| Contact form | Next.js Route Handler + server-side email provider | Use a provider such as Resend or an equivalent service; keep API keys server-only. |
| Hosting | Vercel | Deploy the Next.js application and use its CDN/edge delivery. |
| Persistence | LocalStorage where appropriate | Only for non-sensitive preferences such as light/dark theme. |
| Database | None for initial release | No user accounts, game backend, leaderboard backend, or database is required. |

### Architecture rules

1. Use Server Components by default.
2. Add `"use client"` only to components that require browser interaction, such as the responsive menu, theme toggle, or client-side form feedback.
3. The game iframe itself can be rendered in server-generated HTML. It does not require the entire homepage to become a Client Component.
4. Keep game-provider code and third-party scripts isolated from the rest of the website.
5. Do not load a large game engine, canvas library, animation framework, state-management library, or UI component library for this project.
6. Avoid unnecessary dependencies. Prefer native browser APIs and simple React state for small interactions.
7. Use reusable components and a clear separation between page content, layout, styles, and data.
8. Do not introduce a database, authentication system, or admin dashboard in the initial build.

---

## 3. Design system and visual identity

### 3.1 Exact brand colors

Use these values as the source of truth. Define them as CSS custom properties rather than repeating raw hex values throughout the code.

| Token | Value | Use |
|---|---|---|
| Page background | `#DEE5FC` | Main light-mode page background |
| Brand blue | `#4F78F8` | Menu panel/button and footer background |
| Brand green | `#A7D948` | Hover color for menu/footer links and underline |
| H1 green | `#8ECC39` | All page H1 headings |
| Main text | `#1C1C1C` | Paragraphs, headings other than H1, labels |
| Surface white | `#FFFFFF` | Main homepage content card, blog cards, light header |

Additional neutral shades may be introduced only for borders, disabled states, subtle separators, form fields, and accessible focus indicators. Keep the primary identity based on the six exact colors above.

### 3.2 Typography

- Use **Fredoka** as the website's primary font.
- Load Fredoka through a reliable font-loading method, preferably `next/font/google` if supported in the deployment environment.
- Request only the font weights actually used. Do not load every font weight unnecessarily.
- Use a clear hierarchy: heavier/bolder header controls and page titles; regular, comfortable body text.
- Body text must be readable on mobile. Avoid tiny text and excessively tight line-height.

### 3.3 Overall layout

- Maximum site content width: **1100px**.
- Center the main site container horizontally.
- Use `box-sizing: border-box` globally.
- Use consistent responsive side padding so content never touches the screen edges.
- Maintain a calm, clean, simple appearance. Avoid visual clutter.
- The light-mode body background is `#DEE5FC`.
- The homepage's primary article/content wrapper is white, rounded, and comfortably padded.
- Do not put every paragraph or subsection into its own card. The content wrapper is one continuous surface.
- Avoid glassmorphism, excessive gradients, heavy shadows, unnecessary borders, decorative stickers, floating badges, and gratuitous animations.
- Use restrained radius values consistently. The homepage content wrapper should have clearly rounded corners without looking like a pill.
- Use subtle transitions only for interactive states, such as menu links, buttons, theme switching, and form feedback.

### 3.4 Light and dark theme

Provide a functioning light/dark theme toggle on every page.

**Light mode:**
- Body: `#DEE5FC`.
- Header: white.
- Main content and blog cards: white.
- Main text: `#1C1C1C`.
- H1: `#8ECC39`.
- Footer and menu panel: `#4F78F8`.

**Dark mode:**
- Create a deliberate dark palette with a deep charcoal/navy page background, readable light body text, and a distinct dark surface for content cards.
- Keep the brand blue and green recognizable, but check contrast and readability in every state.
- Do not simply invert the entire page.
- The header must change to a dark surface in dark mode while retaining the same layout.
- Footer and menu panel may retain the brand blue, with white text and green hover state.
- The H1 green must remain legible on dark backgrounds; adjust its dark-mode token only if needed for accessible contrast.
- Respect the user's saved theme preference. If there is no saved preference, use the system preference or default to light mode.
- Prevent a noticeable flash of the wrong theme during page load.
- Theme switching must not cause layout shift.

---

## 4. Header requirements

The header is a high-priority, consistent component used on every page.

### 4.1 Header appearance

- Header background in light mode: `#FFFFFF`.
- Add only a **small, subtle shadow along the bottom edge** to distinguish it from the page background.
- Header content must align with the 1100px site container.
- Header controls and text should be slightly larger and bolder than ordinary body text.
- Keep the header height compact but comfortable. It must not consume excessive vertical space on mobile.

### 4.2 Exact header arrangement

Use a three-column layout, ideally CSS Grid: `1fr auto 1fr`.

1. **Left:** Menu button.
2. **Center:** Text-based brand logo `SNAKEJUEGO`.
3. **Right:** Light/dark theme toggle.

The logo must remain exactly centered in the header, independent of the widths of the left and right controls. The left and right controls should have equal visual spacing from the centered logo. Do not use `space-between` if it causes the logo to drift away from the true center.

### 4.3 Menu button and menu panel

- The menu button must be visible on **all screen sizes**, including desktop. Do not replace it with a row of desktop navigation links.
- Put the menu icon and a clear Spanish label such as `Menú` inside a prominent button.
- Menu button background: `#4F78F8`.
- Menu button text/icon: white.
- Make the touch target comfortably large and accessible.
- On click/tap, open a clear menu panel or dropdown. The panel background must be `#4F78F8`.
- Menu links must be white.
- On hover/focus, links transition smoothly to `#A7D948` and show a smooth underline animation.
- The hover/focus effect must also have a keyboard-accessible equivalent. Do not make color alone the only indication of focus.
- Menu must close when a visitor selects a route, presses Escape, or activates the close control. Manage focus appropriately when opening and closing it.
- Use real links for navigation, not click handlers on non-semantic text.

Suggested Spanish menu links:

- Inicio
- Cómo jugar
- Consejos y estrategias
- Blog
- Sobre nosotros
- Contacto

Legal links can also appear in the menu if the design remains uncluttered, but they must always be reachable from the footer.

### 4.4 Center logo

- Display the exact wordmark **SNAKEJUEGO** in uppercase.
- Use Fredoka with a bold/heavy weight and carefully adjusted letter spacing.
- Make it visually distinctive and polished, but do not add a generic AI-looking icon or Google logo.
- Logo must link to `/` and have an accessible label such as `SNAKEJUEGO — Inicio`.
- Keep it centered on desktop, tablet, and mobile.

### 4.5 Theme toggle

- Place the theme toggle on the far right.
- Use a simple sun/moon icon or similarly clear icon. Do not use emoji.
- Give it an accessible name that changes appropriately, such as `Activar modo oscuro` / `Activar modo claro`.
- Persist the selection in LocalStorage.
- Ensure it works with keyboard and screen readers.

---

## 5. Homepage layout and content

The homepage is the main gaming landing page and must follow the supplied screenshot's broad structure while using the SNAKEJUEGO brand system.

### 5.1 Homepage order

Use this order:

1. Shared header.
2. Main gameplay region near the top of the page.
3. Empty reserved banner-ad space to the right of the game on wide screens.
4. Main Spanish SEO/content section below the game.
5. Shared footer.

Do **not** add the reference screenshot's “Discover more” shopping/advertising block. Do not add fake game recommendations or external promotional widgets.

### 5.2 Main gameplay region

- The game must appear immediately after the header or after only a very small page introduction. It must be prominent and as close to the top of the viewport as practical.
- Use a two-column layout on wide desktop screens:
  - Main column: game area.
  - Right column: blank reserved ad slot.
- The overall layout must stay within the 1100px container.
- Center the iframe inside the main column. Do not center it relative to the whole screen if the reserved right rail would make it look visually off-center.
- Keep the game area visually dominant.
- On narrower screens, collapse to one column and remove/hide the empty reserved ad rail so it does not reduce game size or create awkward whitespace.
- The iframe wrapper must be responsive and must reserve its dimensions before the iframe loads to avoid layout shift.
- Respect the real game embed's required dimensions and behavior. Do not crop controls or game content to force a square if the actual embed needs a different ratio.

### 5.3 Public game iframe integration

Use a configurable environment variable for the exact public embed URL, for example:

```env
NEXT_PUBLIC_SNAKE_GAME_EMBED_URL=https://REPLACE-WITH-THE-PROVIDED-PUBLIC-EMBED-URL
```

Requirements:

- The site owner will supply the exact public embed URL. Do not guess or invent the endpoint.
- The iframe must have a descriptive `title`, such as `Juego Snake de Google`.
- Add `allowFullScreen` if the provider supports fullscreen.
- Add a suitable `referrerPolicy` consistent with the provider's requirements.
- Do not use `loading="lazy"` for the primary game if it is above the fold; the primary game should begin loading promptly.
- Use a responsive wrapper with a stable width/height or `aspect-ratio` based on the actual embed's required dimensions.
- Avoid setting an iframe height that clips its internal controls or game interface.
- If the game provider requires `allow` permissions, include only the minimum permissions actually required and documented by the provider.
- Configure Content Security Policy `frame-src` to allow the exact game host. Do not open it to every domain unnecessarily.
- Do not try to inspect, control, style, or read game internals across a cross-origin iframe. The parent site cannot assume same-origin access.
- Do not claim that the site can access the embedded game's score, events, or settings unless the provider documents a supported API or `postMessage` interface.
- Provide a graceful fallback message in Spanish if the embed URL is missing or the game cannot load. Include a safe link to open the game source separately when the owner has supplied a valid destination URL.
- Do not proxy or mirror the game's content to work around iframe or security restrictions.

### 5.4 Empty right-side ad reservation

- Reserve an empty right-side area for a future banner advertisement on wide desktop screens.
- This area must be genuinely empty in the initial release: no ad creative, no sample image, no text, no placeholder label, no border, no colored box, and no ad script.
- It is a layout reservation only. Use a predictable width appropriate for a future banner slot, such as approximately 300px, and let the actual main content width adapt.
- Do not create a large blank gap that makes the page feel broken. The reserved area should look intentional because of the overall two-column composition, but it should not be visibly outlined.
- Hide/collapse the reservation at tablet/mobile breakpoints.
- Do not add advertising scripts, analytics trackers, or third-party ad pixels in this release.

### 5.5 Homepage content wrapper

Below the game, add one primary white rounded content wrapper in the main content column, similar in hierarchy to the screenshot.

Inside this wrapper:

- Use one clear H1 in Spanish. Suggested direction: `Juega a Snake online` or another concise, natural, search-intent-matched title.
- H1 color: `#8ECC39`.
- Use short, readable Spanish paragraphs.
- Include useful original images relevant to the game, such as a properly licensed or original Snake-game illustration. Images must be responsive, optimized, and have meaningful Spanish alt text.
- Keep text sections directly on the white surface. Do not turn every section into a separate box/card.
- No emojis anywhere in the content.
- Do not use decorative badges, product-style pills, fake testimonials, or unnecessary callout boxes.
- Use natural Spanish, correct spelling, and short paragraphs. Avoid keyword stuffing and repetitive phrases.
- Do not reproduce the screenshot's copy. Write original text based on the real game and verified details.

Suggested homepage content outline:

1. **H1:** `Juega a Snake online` (final wording may be refined for natural Spanish search intent).
2. Introductory paragraph explaining that visitors can play Snake in their browser.
3. A relevant responsive Snake-game image with descriptive alt text.
4. **H2:** `Cómo jugar a Snake` — briefly explain the controls, goal, food, growth, and avoiding collisions. Only describe controls that the embedded game actually supports.
5. **H2:** `Reglas del juego` — explain the real rules accurately and simply.
6. **H2:** `Consejos para conseguir una mejor puntuación` — practical, original advice.
7. **H2:** `Preguntas frecuentes` — concise answers to genuine common questions. Only include FAQs that can be answered accurately.
8. A natural internal link to the full how-to-play guide and relevant blog posts.
9. A brief independence/affiliation disclaimer where appropriate: SNAKEJUEGO is independent and is not affiliated with or endorsed by Google.

The homepage should provide enough original, useful HTML text to explain the experience even when the external iframe does not load. Do not make essential page information available only inside the iframe.

---

## 6. Site map and page requirements

Implement each page below with unique Spanish content, correct metadata, consistent layout, working navigation, and no placeholder paragraphs such as “Lorem ipsum”.

### 6.1 `/` — Inicio / Play Snake

Purpose: Let visitors play quickly and understand what the website offers.

Requirements:
- Shared header.
- Game visible near the top and centered in the main column.
- Empty right-side banner-ad reservation on wide screens only.
- White rounded homepage content wrapper below the game.
- Original Spanish SEO content, game image(s), how-to-play summary, rules, practical tips, and concise FAQs.
- Internal links to `/como-jugar/`, `/consejos-y-estrategias/`, and relevant blog posts.
- Shared footer.

### 6.2 `/como-jugar/` — Cómo jugar

Purpose: Explain how to play the embedded Snake game for beginners.

Content outline:
- Breadcrumb: `Inicio > Cómo jugar`.
- One H1: `Cómo jugar a Snake`.
- Short introduction.
- Controls for desktop and mobile, but document only the controls confirmed to work in the embedded game.
- Goal and rules.
- Food, snake growth, scoring, and collision behavior.
- Beginner instructions in a clear sequence.
- Relevant image or visual only if it improves understanding.
- Link back to the playable homepage and related tips.

Design:
- Plain readable page content; do not turn every step into a separate card.
- Use semantic headings, paragraphs, and lists where they help comprehension.

### 6.3 `/consejos-y-estrategias/` — Consejos y estrategias

Purpose: Give genuinely useful gameplay strategies.

Content outline:
- Breadcrumb.
- H1: `Consejos y estrategias para jugar a Snake`.
- Introductory summary.
- Practical sections such as planning movement, avoiding traps, using available space, controlling speed, and learning from mistakes.
- Explain advice clearly; do not make unsupported claims about game modes or features.
- Link to the game and relevant blog articles.

### 6.4 `/sobre-nosotros/` — Sobre nosotros

Purpose: Explain the site's purpose, who operates it, and its relationship to the embedded game.

Content requirements:
- Breadcrumb.
- H1: `Sobre SNAKEJUEGO`.
- Original Spanish description of the site's purpose and user experience.
- Explain that the site provides access to an externally hosted, publicly embeddable game.
- Clearly state that SNAKEJUEGO is an independent website and is not affiliated with or endorsed by Google.
- Do not invent a company, founder biography, office location, team size, or business history.
- Use owner-supplied details only where they are actually provided.

### 6.5 `/contacto/` — Contacto

Purpose: Give visitors a straightforward way to contact the site operator.

Design:
- Breadcrumb first, then H1 `Contacto`.
- Short Spanish introduction.
- Simple, uncluttered form using the specified brand palette.
- Fields:
  - Nombre (required)
  - Correo electrónico (required, validate email format)
  - Asunto (required)
  - Mensaje (required, sensible maximum length)
  - Privacy acknowledgement checkbox with a link to the privacy policy (required where appropriate to the actual processing basis)
- Submit button with clear loading, success, and error states in Spanish.
- Inputs must be keyboard-accessible, labelled, and visually clear in both themes.
- No unnecessary multi-column form layout on mobile.

Form delivery:
- Implement a server-side Next.js Route Handler, Server Action, or equivalent safe server endpoint.
- Use an email delivery provider such as Resend or another configured provider.
- Keep API keys and receiving email addresses in server-side environment variables; never expose secrets in client code.
- Use the temporary receiver placeholder `contacto@example.com` only during development. This is a placeholder, not a real mailbox; the site owner must replace it with a real monitored address before launch.
- Suggested server-only variables:

```env
CONTACT_TO_EMAIL=contacto@example.com
CONTACT_FROM_EMAIL=replace-with-verified-sender@example.com
EMAIL_PROVIDER_API_KEY=replace-with-real-secret
```

- Validate all fields on the server, not only in the browser.
- Add basic spam protection such as a honeypot field and sensible rate limiting. Do not add invasive CAPTCHA unless spam risk requires it.
- Escape/sanitize user-supplied content appropriately before including it in an email.
- Do not store submitted messages in a database for the initial version unless explicitly required.
- Do not tell visitors that a message was sent unless the email provider confirms success.
- If email credentials are not configured, show a clear development/configuration error rather than falsely reporting success.

### 6.6 `/blog/` — Blog index

Purpose: Present useful Spanish articles related to Snake gameplay and the site.

Required layout:
- Start the main content with a page heading: `Blog de SNAKEJUEGO` or a similarly natural Spanish title.
- Below the heading, show blog cards in a responsive grid.
- **Desktop:** exactly 3 cards per row when there is enough horizontal space.
- **Tablet:** 2 cards per row.
- **Mobile:** 1 card per row.
- Every card must have:
  1. A properly sized cover image.
  2. Article title.
  3. Published date (Spanish locale and readable date format).
  4. A clear button/link such as `Leer artículo`.
- Card background: white in light mode, suitable dark surface in dark mode.
- Cards should be visually consistent, with restrained radius and minimal shadow/border treatment.
- Entire card may be clickable only if the implementation remains accessible; the primary `Leer artículo` link must be clear.
- Use real HTML links.
- Add pagination or a “Cargar más” strategy only when there are enough posts to justify it. Do not implement pagination that hides all articles from crawlers.

Initial article topic suggestions (write original articles, not thin keyword pages):
- Cómo jugar a Snake desde el navegador
- Reglas básicas del juego Snake
- Consejos para conseguir una puntuación más alta en Snake
- Errores comunes al jugar a Snake y cómo evitarlos
- Cómo ha evolucionado el juego Snake (research factual history before publishing dates or historical claims)

Do not publish fabricated author names, fake comments, fictional reader ratings, or invented update dates.

### 6.7 `/blog/[slug]/` — Blog article detail

Each article page must include:
- Breadcrumb: `Inicio > Blog > [Título]`.
- One H1 containing the article title.
- Published date and updated date only when real.
- Main article image with descriptive alt text.
- Readable content width and short paragraphs.
- Logical H2/H3 hierarchy.
- Relevant internal links to the game and other useful articles.
- Related articles section only if actual related content exists.
- Article metadata and Article structured data where appropriate.
- A visible author attribution only if a real author identity is supplied.
- A canonical URL for the article.

Store articles in local MDX or structured content files with typed frontmatter/data: title, slug, description, publishedAt, updatedAt (optional), coverImage, imageAlt, and article body. Validate required fields and handle unknown slugs with a proper 404 response.

### 6.8 Legal pages

Create these pages, each with original, relevant Spanish legal content:

- `/politica-de-privacidad/` — Política de privacidad
- `/politica-de-cookies/` — Política de cookies
- `/aviso-legal/` — Aviso legal
- `/terminos-y-condiciones/` — Términos y condiciones

**Exact legal-page design pattern:**

1. Breadcrumb first.
2. Page H1 second.
3. Optional short introduction or effective-date line.
4. Properly structured plain content using H2/H3 headings, paragraphs, and lists where needed.
5. No card grid, no separate boxed sections, no decorative callout boxes, no emojis, and no excessive visual elements.

Legal-page content must be real and specific to the actual website. Cover only practices that the site actually implements. Do not paste generic legal text that claims the site collects data, uses advertising cookies, analytics, payment systems, user accounts, or third-party processors when those features are not present.

**Privacy policy should address, as applicable to the actual implementation:**
- Identity/contact details of the site operator (owner must provide these; do not invent them).
- What contact-form information is collected.
- Why the information is processed and the applicable legal basis, after owner/legal review.
- Email delivery provider and relevant service providers actually used.
- Retention period or criteria for contact messages.
- Data-subject rights and how to exercise them, where applicable.
- Security practices described accurately without promising absolute security.
- External game iframe: explain that loading the external game may connect the visitor's browser to the game provider and that the provider may process data under its own policies. Identify the actual provider and link its current policy only after verifying the exact embed source.
- Effective date and last-updated date that reflect the real publication date.

**Cookie policy should address:**
- Cookies or local storage actually used by the site.
- The theme preference stored in LocalStorage, if implemented, and clearly distinguish it from a browser cookie.
- Cookies or similar technologies that the external game provider may set, if verified.
- Any future analytics/advertising technologies only after they are implemented.
- A consent banner/configuration mechanism only if non-essential cookies or similar technologies that require consent are introduced. Do not add fake consent settings or claim consent is collected when no such system exists.

**Legal notice should address:**
- Actual owner/operator identity and contact channel (owner to supply).
- Purpose of the website.
- Intellectual property and third-party marks/content.
- External links and embedded third-party content.
- Website liability/disclaimer language reviewed for the target jurisdiction.
- Clear statement that SNAKEJUEGO is independent and not affiliated with Google.

**Terms and conditions should address:**
- Scope and acceptable use of the website.
- Availability and limitations of the external embedded game.
- Third-party service/content disclaimer.
- Intellectual property and permitted use of site content.
- Availability, maintenance, and changes to the website.
- Contact method and effective date.

Do not represent the legal content as legal advice. Add a launch checklist item requiring the owner to provide actual legal identity and contact details and have the pages reviewed for the jurisdictions in which the site operates. Do not publish unfilled placeholders as if they were factual legal disclosures.

---

## 7. Footer requirements

Use a consistent footer on every page.

### Appearance

- Background: exactly `#4F78F8`.
- Text and links: white.
- Link hover/focus color: `#A7D948`.
- Use a smooth underline transition matching the menu links.
- Footer must look clean, balanced, and spacious without being unnecessarily tall.
- Ensure text and link contrast remains accessible.

### Footer content

Include:
1. The SNAKEJUEGO wordmark/logo in white or a suitable accessible white treatment.
2. Main site navigation links.
3. Legal links:
   - Política de privacidad
   - Política de cookies
   - Aviso legal
   - Términos y condiciones
4. Copyright line, for example: `© [current year] SNAKEJUEGO. Todos los derechos reservados.`

Use a real current year, not a hardcoded outdated year. Links must lead to valid pages. Footer items should wrap cleanly on small screens. Do not add ad links, fake social profiles, or unprovided contact details.

---

## 8. Favicon and site assets

- Create a custom **rounded favicon** for SNAKEJUEGO.
- Prefer a simple original snake-inspired mark or stylized letter `S` inside a rounded square/circle.
- Use the brand palette, with strong contrast at small sizes.
- Do not use Google's logo or copy the favicon of the reference website.
- Export the necessary favicon/app icon formats supported by Next.js, including a browser favicon and an appropriate touch/app icon.
- Ensure metadata points to the correct icons.
- Use original or properly licensed imagery only. Do not hotlink images from the reference website.
- Optimize raster images to WebP/AVIF where suitable and provide intrinsic dimensions to prevent layout shift.
- Use descriptive file names and Spanish alt text for meaningful images. Decorative images should have empty alt text.

---

## 9. Content and editorial requirements

All public-facing content must be written in natural Spanish.

- Use Spanish consistently across the interface, navigation, metadata, forms, error messages, blog, and legal pages.
- Use correct grammar, accents, punctuation, and natural phrasing.
- Keep paragraphs relatively short and easy to scan.
- Prefer direct explanations over filler introductions.
- No emojis.
- No keyword stuffing, repetitive exact-match phrases, or awkward SEO sentences.
- Do not create content just to increase word count.
- Do not make unsupported claims about game modes, game controls, availability, features, history, or compatibility.
- Verify historical facts before publishing them.
- Do not claim that the game works offline unless this has been tested and is genuinely supported by the external embed.
- Do not claim that the external game is controlled or operated by SNAKEJUEGO.
- Ensure each page has a distinct purpose and avoid duplicating the homepage text across multiple URLs.
- Use internal links naturally where they help visitors continue learning or playing.

### Spanish terminology

Use clear Spanish labels, for example:
- Menú
- Inicio
- Jugar
- Cómo jugar
- Consejos y estrategias
- Blog
- Sobre nosotros
- Contacto
- Leer artículo
- Enviar mensaje
- Nombre
- Correo electrónico
- Asunto
- Mensaje
- Política de privacidad
- Política de cookies
- Aviso legal
- Términos y condiciones

Use one consistent Spanish variant and avoid switching between regional terms unnecessarily.

---

## 10. Technical SEO requirements

SEO must be implemented in the actual rendered HTML and page architecture, not merely described in a checklist.

### 10.1 Rendering and crawlability

- Use static generation for the homepage, informational pages, legal pages, blog index, and articles when content is available at build time.
- Keep the homepage's primary Spanish content in server-rendered HTML. Do not require JavaScript execution before the core text, heading, navigation links, and internal links exist in the DOM.
- The embedded game is an enhancement/experience and must not be the only meaningful content on the homepage.
- Do not build the entire page as a client-only application.
- Use server components by default and keep client components small.
- Use real `<a>` links for navigation and internal linking.
- Ensure all indexable pages return the correct HTTP status code, normally `200` for valid pages and `404` for missing pages.
- Do not block CSS, JavaScript, fonts, or essential resources needed to render the page.
- Do not depend on the external iframe's contents being indexed. Google should be able to understand the website from its own HTML content.

### 10.2 Metadata

Use the Next.js Metadata API for unique page metadata.

Every indexable page must have:
- Unique, meaningful `<title>` in Spanish.
- Unique meta description in Spanish.
- Correct canonical URL.
- Appropriate robots directives.
- Open Graph title, description, and image where relevant.
- Social sharing metadata.

Avoid duplicate titles/descriptions. Do not set the entire site to `noindex`. Do not add arbitrary meta keywords tags as an SEO tactic.

### 10.3 URL structure

Use short, readable, lowercase Spanish slugs with hyphens. Keep URLs stable. Avoid query parameters for normal page navigation. Use trailing slash behavior consistently (either all canonical URLs with trailing slash or all without; do not create duplicates).

### 10.4 Sitemap and robots

- Generate a valid XML sitemap containing all canonical, indexable pages and published blog posts.
- Exclude drafts, invalid routes, preview URLs, and duplicate URLs.
- Create a valid `robots.txt` that allows crawling of public pages and references the sitemap.
- Do not disallow Next.js assets or essential public files.
- Do not include private environment data or secrets in public output.

### 10.5 Structured data

Add JSON-LD only when the page genuinely qualifies and the data is visible and accurate.

Recommended where appropriate:
- `WebSite` for the website.
- `Article` or `BlogPosting` for individual blog articles.
- `BreadcrumbList` for pages where visible breadcrumbs exist.

Do not fabricate ratings, reviews, author identities, dates, organization details, or FAQ markup. Do not add unsupported structured data solely to seek rich results. Validate JSON-LD before launch.

### 10.6 Heading structure

- One clear H1 per page.
- Use H2 for major sections and H3 for subsections.
- Do not use heading tags only for visual styling.
- Keep the H1 green (`#8ECC39`) as required; other headings use the normal heading/text color (`#1C1C1C`) in light mode.
- Maintain logical hierarchy without skipping levels unnecessarily.

### 10.7 Images and media SEO

- Optimize images and serve responsive sizes.
- Specify width and height or a stable aspect ratio.
- Use descriptive filenames and meaningful Spanish alt text.
- Lazy-load below-the-fold images.
- Do not lazy-load the primary above-the-fold game iframe.
- Avoid large, uncompressed hero images.
- Do not use stock images with watermarks or images copied from competitors.

### 10.8 Internal links and breadcrumbs

- Use crawlable HTML links with descriptive Spanish anchor text.
- Every important page must be reachable through navigation, footer, or contextual internal links.
- Add visible breadcrumbs to informational, blog-detail, and legal pages. The homepage itself does not need a breadcrumb.
- Breadcrumbs must use actual page hierarchy and link to existing routes.

---

## 11. Performance and Core Web Vitals

Build for real-world mobile performance, not just a good Lighthouse screenshot.

Targets to aim for at the 75th percentile of real user visits:

- **LCP:** 2.5 seconds or less.
- **INP:** less than 200 milliseconds.
- **CLS:** less than 0.1.

Implementation requirements:

1. Keep the initial JavaScript bundle small.
2. Do not load unnecessary libraries or animation packages.
3. Use static generation and server-rendered HTML for content pages.
4. Load only the required Fredoka font weights.
5. Optimize and correctly size all images.
6. Reserve dimensions for the iframe, images, cards, and any future ad slot to prevent layout shift.
7. Do not inject advertising scripts or third-party analytics in the first release.
8. Avoid blocking scripts in the document head.
9. Use caching and the deployment platform's CDN appropriately.
10. Minimize unnecessary hydration and re-renders.
11. Avoid excessive DOM nesting and overly complex CSS selectors.
12. Test on a throttled mobile connection and a mid-range mobile device profile.
13. Measure the impact of the external game iframe separately. The provider's load time is not fully under SNAKEJUEGO's control, so report it separately rather than pretending it can be optimized internally.
14. Do not lazy-load the primary game if doing so undermines the above-the-fold experience.
15. Do not preload every image/font. Preload only genuinely critical resources.

---

## 12. Responsive design requirements

Support small phones, large phones, tablets, laptops, and wide desktop displays.

### Desktop

- Site container max width 1100px.
- Header uses left menu button, truly centered logo, right theme toggle.
- Menu button remains visible; no desktop horizontal navigation replacement.
- Homepage uses main gameplay/content column plus a reserved blank right ad rail.
- Blog grid displays 3 cards per row.
- Content widths and paragraph line lengths remain comfortable.

### Tablet

- Keep the same header arrangement and menu-button pattern.
- Reduce outer spacing and game dimensions appropriately.
- Hide or collapse the reserved ad rail when it would constrain the main content.
- Blog grid displays 2 cards per row.

### Mobile

- Keep the menu button on the left, wordmark centered, theme toggle on the right.
- Do not replace the menu button with a hamburger-less layout.
- Prevent the logo from colliding with either control. Use responsive sizing while preserving true visual centering.
- Game iframe must fit the available width without horizontal scrolling or clipping.
- Hide the reserved ad rail entirely.
- Homepage content wrapper must use comfortable side padding and not touch the viewport edges.
- Blog grid displays 1 card per row.
- Footer content wraps cleanly.
- Forms use one column.
- All controls must have touch-friendly hit areas.
- No horizontal overflow at 320px viewport width.

Use fluid sizing with sensible breakpoints rather than designing only for one screenshot width.

---

## 13. Accessibility requirements

- Use semantic HTML landmarks: `header`, `nav`, `main`, `article`, `aside` where appropriate, and `footer`.
- Use a real button for menu and theme controls.
- Use real links for navigation.
- Ensure keyboard access to all interactive controls.
- Provide visible focus indicators.
- Support Escape to close the menu.
- Use accessible names for icon-only controls.
- Label every form field explicitly.
- Associate validation errors with their respective fields.
- Announce form status messages accessibly.
- Maintain sufficient color contrast, including green hover states and dark mode.
- Respect `prefers-reduced-motion`; keep transitions short and disable non-essential animation when requested.
- Use meaningful alt text for informative images and empty alt for decorative images.
- Ensure the iframe has a useful title.
- Do not communicate important state through color alone.

---

## 14. Security, privacy, and reliability

- Keep all secret keys server-side.
- Validate and sanitize contact-form submissions on the server.
- Add rate limiting or an equivalent abuse-control layer to the form endpoint.
- Configure a restrictive Content Security Policy appropriate to the actual assets and iframe host.
- Restrict `frame-src` to the verified game embed origin.
- Do not use `unsafe-eval` or broad wildcard policies unless a verified technical requirement makes them unavoidable; document any exception.
- Use HTTPS in production.
- Do not add unnecessary cookies or trackers.
- Do not store sensitive information in LocalStorage.
- Handle missing game embed configuration gracefully.
- Handle email-provider outages with a truthful user-facing error.
- Avoid exposing detailed server errors or secrets to visitors.
- Add basic security headers supported by the hosting setup.
- Do not create a custom backend proxy for the game.

---

## 15. Suggested project structure

Use a clean, maintainable App Router structure similar to this. Adjust names only when there is a clear benefit.

```text
snakejuego/
├── public/
│   ├── images/
│   │   ├── snake-game-cover.webp
│   │   └── blog/
│   ├── favicon.ico
│   ├── icon.png
│   ├── apple-icon.png
│   └── og-image.png
├── src/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   ├── globals.css
│   │   ├── robots.ts
│   │   ├── sitemap.ts
│   │   ├── icon.tsx
│   │   ├── como-jugar/
│   │   │   └── page.tsx
│   │   ├── consejos-y-estrategias/
│   │   │   └── page.tsx
│   │   ├── sobre-nosotros/
│   │   │   └── page.tsx
│   │   ├── contacto/
│   │   │   └── page.tsx
│   │   ├── blog/
│   │   │   ├── page.tsx
│   │   │   └── [slug]/
│   │   │       └── page.tsx
│   │   ├── politica-de-privacidad/
│   │   │   └── page.tsx
│   │   ├── politica-de-cookies/
│   │   │   └── page.tsx
│   │   ├── aviso-legal/
│   │   │   └── page.tsx
│   │   ├── terminos-y-condiciones/
│   │   │   └── page.tsx
│   │   └── api/
│   │       └── contact/
│   │           └── route.ts
│   ├── components/
│   │   ├── Header.tsx
│   │   ├── MenuButton.tsx
│   │   ├── MenuPanel.tsx
│   │   ├── ThemeToggle.tsx
│   │   ├── Footer.tsx
│   │   ├── Breadcrumbs.tsx
│   │   ├── GameEmbed.tsx
│   │   ├── AdReservation.tsx
│   │   ├── HomeContent.tsx
│   │   ├── BlogCard.tsx
│   │   ├── BlogGrid.tsx
│   │   └── ContactForm.tsx
│   ├── content/
│   │   └── blog/
│   ├── lib/
│   │   ├── blog.ts
│   │   ├── metadata.ts
│   │   ├── email.ts
│   │   └── site-config.ts
│   └── types/
│       └── blog.ts
├── .env.example
├── next.config.ts
├── package.json
└── tsconfig.json
```

Do not create files that are not needed. The suggested structure is a guide for separation of concerns, not a requirement to over-engineer the project.

---

## 16. Site-wide navigation map

### Header menu

- Inicio → `/`
- Cómo jugar → `/como-jugar/`
- Consejos y estrategias → `/consejos-y-estrategias/`
- Blog → `/blog/`
- Sobre nosotros → `/sobre-nosotros/`
- Contacto → `/contacto/`

### Footer links

Include the main links above plus:

- Política de privacidad → `/politica-de-privacidad/`
- Política de cookies → `/politica-de-cookies/`
- Aviso legal → `/aviso-legal/`
- Términos y condiciones → `/terminos-y-condiciones/`

All links must work. Do not create dead links or placeholder `#` links.

---

## 17. Content and metadata starter direction

Create unique Spanish titles and descriptions for each page. These are starting directions, not mandatory final copy; refine naturally without keyword stuffing.

| Route | Suggested title direction | Suggested description direction |
|---|---|---|
| `/` | Juega a Snake Online | SNAKEJUEGO | Juega a Snake desde tu navegador y consulta reglas, controles y consejos para disfrutar la partida. |
| `/como-jugar/` | Cómo Jugar a Snake: Controles y Reglas | SNAKEJUEGO | Aprende cómo jugar a Snake, conoce sus controles y entiende las reglas básicas paso a paso. |
| `/consejos-y-estrategias/` | Consejos y Estrategias para Snake | SNAKEJUEGO | Descubre consejos prácticos para moverte mejor, evitar choques y mejorar tu puntuación en Snake. |
| `/sobre-nosotros/` | Sobre SNAKEJUEGO | Conoce el propósito de SNAKEJUEGO y cómo ofrecemos acceso al juego desde el navegador. |
| `/contacto/` | Contacto | SNAKEJUEGO | Ponte en contacto con SNAKEJUEGO para consultas, comentarios o cuestiones relacionadas con el sitio. |
| `/blog/` | Blog de Snake: Guías y Consejos | SNAKEJUEGO | Lee guías, consejos y artículos útiles para aprender y disfrutar del juego Snake. |

Every blog article needs its own title, description, canonical, Open Graph details, and article content.

---

## 18. Testing and quality assurance

Before calling the project complete, run and document all relevant checks.

### Functional testing

- Menu opens and closes on desktop, tablet, and mobile.
- Menu links navigate to the correct pages.
- Menu closes on Escape and after route selection.
- Logo returns to homepage.
- Theme toggle works on every page.
- Theme preference persists after navigation and reload.
- The game iframe loads from the configured public URL.
- The game is usable at common desktop and mobile sizes.
- Fullscreen works if supported by the embed provider.
- Missing/invalid iframe URL shows a graceful fallback.
- Contact form validates fields and shows accurate success/error states.
- Contact form sends to the configured real recipient when credentials are present.
- Blog cards open the correct article.
- Unknown blog slugs show a real 404 page.
- All footer and legal links work.

### Responsive testing

Test at minimum:
- 320px mobile width.
- 375px mobile width.
- 430px mobile width.
- 768px tablet width.
- 1024px laptop/tablet landscape width.
- 1280px desktop width.
- 1440px wide desktop width.

Check for horizontal overflow, clipped iframe content, overlapping header controls, awkward empty ad space, and broken card grids.

### SEO testing

- Inspect raw page source and confirm the core Spanish content is present in initial HTML.
- Confirm one H1 per page.
- Confirm unique title and meta description per indexable route.
- Confirm canonicals point to the correct production URLs.
- Validate sitemap and robots.txt.
- Validate JSON-LD.
- Confirm all important pages are internally linked.
- Confirm the site does not accidentally use `noindex` in production.
- Check 404 responses and missing routes.
- Use Google Search Console URL Inspection after deployment to confirm Google can fetch and render key pages.

### Performance testing

- Run Lighthouse on the homepage and representative inner pages.
- Measure mobile and desktop.
- Inspect LCP, INP, and CLS.
- Identify whether the embedded game provider is the main external loading bottleneck.
- Ensure the iframe and images do not create avoidable layout shifts.
- Check font loading and unused JavaScript.
- Do not claim a performance score that has not actually been measured.

### Accessibility testing

- Keyboard-only navigation.
- Visible focus state.
- Form label/error association.
- Menu keyboard behavior.
- Screen-reader labels for menu and theme controls.
- Color contrast in light and dark modes.
- Reduced-motion preference.

---

## 19. Launch configuration checklist

Before production launch, confirm these owner-supplied values:

- [ ] Production domain and canonical base URL.
- [ ] Exact public game iframe URL.
- [ ] Verified embed provider hostname for the Content Security Policy.
- [ ] Real contact recipient email address (replace `contacto@example.com`).
- [ ] Verified sender email address and email-provider credentials.
- [ ] Actual website owner/operator identity for legal pages.
- [ ] Actual legal contact address/details required for the site's jurisdiction.
- [ ] Actual data retention and contact-form processing practices.
- [ ] Current third-party privacy/cookie information for the embedded game provider.
- [ ] Final original logo/favicon and licensed images.
- [ ] Production Search Console property and sitemap submission.

Do not silently replace missing information with invented facts. Use development placeholders only in non-production and prevent deployment to production until required values are configured.

---

## 20. Definition of done

The website is complete only when all of the following are true:

1. SNAKEJUEGO has a polished, consistent visual identity using the specified colors and Fredoka font.
2. Header has the menu on the left, perfectly centered SNAKEJUEGO wordmark, and theme toggle on the right on every device size.
3. Menu button is visible on desktop as well as mobile; desktop horizontal navigation links do not replace it.
4. Header is white in light mode with a subtle bottom shadow.
5. Menu panel is `#4F78F8`, links are white, and hover/focus uses `#A7D948` with a smooth underline.
6. Footer background is `#4F78F8`, text/links are white, and hover/focus uses `#A7D948` with a smooth underline.
7. Main page background is `#DEE5FC` in light mode; main homepage content and blog cards are white.
8. All H1 headings use `#8ECC39` in light mode; general text and other headings use `#1C1C1C`.
9. The game appears prominently near the top, is centered in the main column, and loads from the exact owner-supplied public embed URL.
10. A blank future ad reservation exists to the right of the game on wide screens, but no actual advertisements or ad scripts are included.
11. The homepage content appears below the game in one rounded white wrapper with original Spanish text and relevant images. It contains no emojis or unnecessary inner boxes.
12. The blog page starts with a heading and uses a 3-column desktop, 2-column tablet, and 1-column mobile card grid. Each card has an image, title, published date, and article link/button.
13. Contact page has a simple, validated, accessible Spanish form and uses a real server-side delivery integration when configured. The dummy receiver is clearly treated as a development placeholder only.
14. Legal pages begin with a breadcrumb and H1, followed by properly structured plain content with no boxed sections. Their statements match the actual site's practices.
15. All pages are in Spanish and have unique metadata and correct canonical URLs.
16. Core text and internal links are present in server-rendered HTML without requiring client-side JavaScript.
17. Sitemap, robots.txt, structured data, 404 behavior, responsive layouts, light/dark mode, accessibility, and security configuration are implemented and tested.
18. No fake testimonials, fake reviews, fake author data, invented company details, fake contact success messages, fake ad placements, or copied competitor content remain.
19. Build, lint, and type checks pass. No important console errors or broken routes remain.
20. A concise handover note lists the stack, environment variables, deployment steps, owner-supplied launch requirements, and any known limitations of the external game embed.

---

## 21. Final instruction to the coding agent

Build the complete SNAKEJUEGO website according to this PRD. First inspect the supplied reference screenshot and identify its layout hierarchy, but follow the new brand specifications in this document rather than copying the reference site. Implement the real routes and working interactions, not just a visual prototype. Prioritize a fast server-rendered content experience with the external game embedded in a stable responsive frame. Keep the project lightweight, accessible, maintainable, and production-ready.

Before finishing, run the required checks and provide:

1. A summary of completed pages and components.
2. The exact stack and important dependencies.
3. All environment variables that must be configured.
4. Any owner information still needed for legal pages and contact delivery.
5. The results of build, lint, type-check, responsive, SEO, and performance checks.
6. Any limitation caused by the external game provider that is outside the website's control.

Do not claim a check passed unless it was actually executed.

---

## 22. Official technical references

Use the current official documentation while implementing; APIs may change between framework releases.

- Next.js App Router: https://nextjs.org/docs/app
- Next.js Metadata API: https://nextjs.org/docs/app/getting-started/metadata-and-og-images
- Next.js static route generation: https://nextjs.org/docs/app/api-reference/functions/generate-static-params
- Google JavaScript SEO basics: https://developers.google.com/search/docs/crawling-indexing/javascript/javascript-seo-basics
- Google Core Web Vitals: https://developers.google.com/search/docs/appearance/core-web-vitals
- Vercel documentation: https://vercel.com/docs

